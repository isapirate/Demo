package top.axyz.demo.bean;

import java.io.Serializable;

public class Info implements Serializable {

    private static final long serialVersionUID = 1070004099197689357L;

    private String image;         // 图片的URL
    private String content;       // 文字内容

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
