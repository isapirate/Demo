package top.axyz.application;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private final String TAG = MainActivity.class.getSimpleName();

    // 当前的上下文
    private final Context CONTEXT = this;

    // 设置超时时间为15秒
    private final int TIME_OUT = 15;

    // 请求数据的地址
    private final String URL = "https://raw.githubusercontent.com/isapirate/Demo/master/info";

    private ProgressBar progressBar;
    private AppCompatImageView imageView;
    private AppCompatTextView textView;
    private AppCompatButton button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    /**
     * 初始化控件
     */
    private void initView() {
        progressBar = findViewById(R.id.progressBar);
        imageView = findViewById(R.id.imageView);
        textView = findViewById(R.id.textView);
        button = findViewById(R.id.button);
        // 点击事件监听
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                requestData();
            }
        });
    }

    /**
     * 请求网路数据
     */
    private void requestData() {
        // 实例化OkHttpClient
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(TIME_OUT, TimeUnit.SECONDS)
                .readTimeout(TIME_OUT, TimeUnit.SECONDS)
                .writeTimeout(TIME_OUT, TimeUnit.SECONDS)
                .build();
        // 请求设置
        final Request request = new Request.Builder().url(URL).get().build();

        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            // 请求失败
            public void onFailure(Call call, IOException e) {
                showMsg(e.getMessage());
            }

            // 请求响应
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    // 获取接口中数据
                    String json = response.body().string();
                    // Log.e(TAG, json);
                    parseData(json);
                } else {
                    showMsg(response.message());
                }
            }
        });
    }


    /**
     * 解析json数据
     *
     * @param json
     */
    private void parseData(String json) {
        if (null != json) {
            // 实例化Gson
            Gson gson = new Gson();
            // json字符串转成实体类
            Result<Info> result = gson.fromJson(json, new TypeToken<Result<Info>>() {
            }.getType());

            // 判断获取的数据是否正常
            if (result.getStatus() == 200) {
                Info info = result.getData();
                displayView(info);
            } else {
                showMsg(result.getMessage());
            }
        }
    }

    /**
     * 展示数据
     *
     * @param info
     */
    private void displayView(final Info info) {
        if (null != info) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    textView.setText(info.getContent());
                    Glide.with(CONTEXT).load(info.getImageUrl()).into(imageView);
                    progressBar.setVisibility(View.GONE);
                }
            });
        }
    }


    /**
     * 提示信息
     *
     * @param message
     */
    private void showMsg(final String message) {
        if (null != message) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(CONTEXT, message, Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.GONE);
                }
            });
        }
    }
}