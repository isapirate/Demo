package top.axyz.application;

import java.io.Serializable;

public class Result<T> implements Serializable {
    private static final long serialVersionUID = 3075346615416274627L;

    private int status;      // 状态码
    private String message;  // 提示信息
    private T data;          // 数据

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
