package top.axyz.application;

import java.io.Serializable;

public class Info implements Serializable {
    private static final long serialVersionUID = 6063687274134564504L;

    private String imageUrl;    // 图片的下载地址
    private String content;     // 文字内容

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}