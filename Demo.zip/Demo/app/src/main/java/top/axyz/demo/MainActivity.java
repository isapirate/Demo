package top.axyz.demo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.widget.PopupWindowCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button);
        button.setOnClickListener((view) -> {


            View contentView = LayoutInflater.from(this).inflate(R.layout.popup_main, null, false);
            RecyclerView recyclerView = contentView.findViewById(R.id.recyclerView);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));

            PopupWindow popupWindow = new PopupWindow(contentView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

            List<String> list = new ArrayList<>();
            list.add("Android");
            list.add("sadfasdfasd");
            list.add("asdfasdfas");
            list.add("asdfasdf");
            MainAdapter mainAdapter = new MainAdapter(this, list);
            recyclerView.setAdapter(mainAdapter);
            mainAdapter.setOnItemClickListener((view1, position) -> {
                popupWindow.dismiss();
            });


            popupWindow.setFocusable(true);
            popupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

            ConstraintLayout constraintLayout = findViewById(R.id.constraintLayout);

            // popupWindow.showAtLocation(button, Gravity.BOTTOM, 0, 0);
            popupWindow.showAsDropDown(button, 100, 0);

        });
    }
}
