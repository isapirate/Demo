$(function(){
	$.ajaxSetup ({cache: false});
	var $addForm = $('#addForm');
	$('#submit').click(function() {
		$('#listManage').triggerHandler('taijiModalPost', [ $(this), $addForm, {optType:'add'} ]);
	});
	$addForm.find('#list').val('');
	$addForm.find('#iconCls').change(function() {
		$addForm.find('#showIcon').removeClass().addClass($(this).val());
	});
});