$(function(){
	$.ajaxSetup ({cache: false});
//	$('#assetFidldset').hide();
	$('#assetInventory').hide();
	$("#specialClean").hide();
	
	$('#saveSubmit').click(function() {
		$('#listManage').triggerHandler('taijiModalPost', [ $(this), $('#addForm'), {optType:'add'} ]);
	});
	$('#addAsset').click(function(){
		$('#addAsset').attr("href","${rootUrl}app/work/request/addasset")
	});
	$('#deleteAsset').click(function(){
		$('#assetInventory').hide().find('tbody').empty();
	});
	$('#spaceId').change(function(){
		$selected = $(this).find('option:selected');
		$('#floor').val($selected.data('floor'));
		$('#room').val($selected.data('room'));
	});
	$('#wrtypeId').change(function(){
		var selectedValue = $(this).val();		
		$('#wrsubTypeId').val(null);
		$('#wrsubTypeId').select2('val','');
		$('#wrsubTypeId').empty();
		$.get(
			"${rootUrl}app/work/request/getWRSubTypeIdByWRTypeId?wRTypeId="+selectedValue,
			function(data,status){
				var option = "";
				for(var i=0;i<data.length;i++){
					option += "<option value='"+data[i].id+"' data-desc="+data[i].pinyin+">"+data[i].wrSubTypeDesc+"</option>";
					$('#wrsubTypeId').html(option);
				}
				
				$('#wrsubTypeId').change();
			},"json"
		);
	});
	$('#wrtypeId').change();
	$('#wrsubTypeId').change(function(){
		var selectedValue = $(this).val();		
		$('#problemId').val(null);
		$('#problemId').select2('val','');
		$('#problemId').empty();
		$.get(
			"${rootUrl}app/work/request/getProblemByWrSubTypeId?wrSubTypeId="+selectedValue,
			function(data,status){
				var option = "";
				for(var i=0;i<data.length;i++){
					option += "<option value='"+data[i].id+"' data-desc="+data[i].pinyin+" data-standardInterval="+(data[i].timeCode == null ? 0 : data[i].timeCode.standardInterval)+">"+data[i].problemDesc+"</option>";
				}
				$('#problemId').html(option);
			},"json"
		);
	});
	
	$('#problemId').change(function(){
		var option = $(this).find('option:selected');
		var standardInterval = option.attr('data-standardInterval');
		var neededTime = new Date();
		if(standardInterval){
			neededTime.setTime(neededTime.getTime()+standardInterval*60*1000);
		}
		$('#dateNeeded').val(formartDate(neededTime));
		var timeNow = new Date();
		timeNow.toLocaleString();
		$('#requestDate').val(formartDate(timeNow));
	});
});
function formartDate(date){
	return date.getFullYear() + (date.getMonth() < 9 ? '-0' : '-') + (date.getMonth() + 1) 
		+ (date.getDate()<9? '-0':'-') + date.getDate() + (date.getHours()<9? ' 0':' ')+date.getHours()
		+ (date.getMinutes()<9 ? ':0':':') + date.getMinutes();
}