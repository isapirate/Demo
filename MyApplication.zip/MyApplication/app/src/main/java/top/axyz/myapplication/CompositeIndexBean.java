package top.axyz.myapplication;

/**
 * Created by xhu_ww on 2018/6/1.
 * description:
 */
public class CompositeIndexBean {
    private double rate;
    private String tradeDate;

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public String getTradeDate() {
        return tradeDate;
    }

    public void setTradeDate(String tradeDate) {
        this.tradeDate = tradeDate;
    }
}
