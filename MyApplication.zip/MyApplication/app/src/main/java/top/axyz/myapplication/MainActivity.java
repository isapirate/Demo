package top.axyz.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        List<DialogMemberBean> contactTreeList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            DialogMemberBean bean = new DialogMemberBean();
            bean.setName("aaaasdfasdfasdfd");
            contactTreeList.add(bean);
        }

        TextView textView = findViewById(R.id.textView);
        textView.setOnClickListener((view) -> {
            DialogHelper.create(this).setSelectorData(contactTreeList).setSelectorListener(new DialogHelper.OnHelperSelectorListener() {
                @Override
                public void getSelectorPosition(List<DialogMemberBean> trees) {
                    if (trees.size() == 0) {
                        Log.e("getSelectorPosition:", "=====");
                    } else {

                        Log.d("====", trees.get(0).getName());
                        Log.e("getSelectorPosition:", String.valueOf(trees));
                    }
                }
            }).showSelectorDialog();
        });


    }
}
