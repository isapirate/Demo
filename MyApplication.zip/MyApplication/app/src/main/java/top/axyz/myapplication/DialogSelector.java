package top.axyz.myapplication;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class DialogSelector extends Dialog implements DialogMemberAdapter.OnItemClickListener {
    private List<DialogMemberBean> DialogMemberBean = new ArrayList<>();    //选择列表的数据
    private List<DialogMemberBean> DialogMemberBeanselector = new ArrayList<>();
    private Context context;
    private OnSelectorListener cdListener;
    private DialogMemberAdapter mSelectorBranchAdapter;
    private Button btn_cancel;
    private Button btn_ok;
    private RecyclerView rv_selector_branch;


    public DialogSelector(Context context, List<DialogMemberBean> mSimpleListItemEntity, OnSelectorListener cdListener) {
        super(context);
        this.context = context;
        this.cdListener = cdListener;
        this.DialogMemberBean = mSimpleListItemEntity;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.dialog_content);
        this.setCanceledOnTouchOutside(false); // 点击外部会消失
        InitViews();
    }

    private void InitViews() {
        btn_cancel = findViewById(R.id.btn_cancel);
        btn_ok = findViewById(R.id.btn_ok);
        rv_selector_branch = (RecyclerView) findViewById(R.id.rv_selector);
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cdListener.cancel();
            }
        });

        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < DialogMemberBean.size(); i++) {
                    if (DialogMemberBean.get(i).isSelector()) {
                        DialogMemberBeanselector.add(DialogMemberBean.get(i));
                    }
                }
                cdListener.getSelectorData(DialogMemberBeanselector);
            }
        });

        LinearLayoutManager layoutmanager = new LinearLayoutManager(getContext());
        rv_selector_branch.setLayoutManager(layoutmanager);
        mSelectorBranchAdapter = new DialogMemberAdapter(DialogMemberBean);
        mSelectorBranchAdapter.setOnItemClickListener(this);
        rv_selector_branch.setAdapter(mSelectorBranchAdapter);
    }

    /**
     * adpter里面的checkbox监听接口
     *
     * @param position item的位置
     *                 改变元数据集的内容
     */
    @Override
    public void onItemClick(int position) {
        boolean temp = !DialogMemberBean.get(position).isSelector();
        DialogMemberBean.get(position).setSelector(temp);
    }

    /**
     * 确定 和 取消控件的回调接口
     */
    public interface OnSelectorListener {

        void getSelectorData(List<DialogMemberBean> trees);

        void cancel();
    }
}